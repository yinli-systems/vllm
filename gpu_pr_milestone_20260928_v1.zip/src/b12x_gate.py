"""Frozen numerical gate for B12X; independent packed-FP4 decoding, no speed claim."""
import os,sys,json,hashlib,inspect,statistics,traceback
from pathlib import Path
import torch
import flashinfer
from flashinfer.cute_dsl.utils import convert_sf_to_mma_layout
POLICY={'nvfp4':{'relative_l2_max':0.06,'cosine_min':0.998},'w4a16':{'relative_l2_max':0.02,'cosine_min':0.9998},'reference':'independent FP4 nibble+E4M3 scale decode; FP32 expert GEMMs; NVFP4 input and post-SiLU activation use separately quantized packed values; W4A16 preserves BF16 inputs','negative_controls':['zero_output','double_output','swapped_gate_and_up'],'performance_claim':False,'statistical_model_quality_claim':False}
LUT=[0.,.5,1.,1.5,2.,3.,4.,6.,-0.,-.5,-1.,-1.5,-2.,-3.,-4.,-6.]
def decode(q,sf,rows,cols,global_scale=1.):
    lut=torch.tensor(LUT,device=q.device,dtype=torch.float32)
    codes=torch.stack([q&15,q>>4],dim=-1).reshape(rows,cols)
    scales=sf.view(torch.float8_e4m3fn).float().reshape(rows,cols//16)
    return lut[codes.long()]*scales.repeat_interleave(16,dim=-1)/global_scale

def qdq(x):
    q,sf=flashinfer.fp4_quantize(x.bfloat16().contiguous(),global_scale=torch.ones(1,device='cuda'),sf_vec_size=16,is_sf_swizzled_layout=False)
    return decode(q,sf,x.shape[0],x.shape[1])

def weights(e,n,k):
    lut=torch.tensor(LUT,device='cuda');w=(lut[torch.randint(0,16,(e,n,k),device='cuda')]*.0625).bfloat16();w[...,::16]=.375
    q,sf=flashinfer.fp4_quantize(w.reshape(e*n,k),global_scale=torch.ones(1,device='cuda'),sf_vec_size=16,is_sf_swizzled_layout=False)
    d=decode(q,sf,e*n,k).reshape(e,n,k);assert torch.equal(d,w.float()),'Fixture must be exactly FP4-representable'
    q2,s2=flashinfer.fp4_quantize(w.reshape(e*n,k),global_scale=torch.ones(1,device='cuda'),sf_vec_size=16,is_sf_swizzled_layout=True)
    assert torch.equal(q,q2)
    s2=convert_sf_to_mma_layout(s2,m=n,k=k,num_groups=e,sf_vec_size=16)
    return d,q2.reshape(e,n,k//2),s2

def reference(x,w1,w2,ids,scales,mode,wrong=False):
    xin=qdq(x) if mode=='nvfp4' else x.float();out=torch.zeros_like(x,dtype=torch.float32);n=w2.shape[-1]
    for e in range(w1.shape[0]):
        rows,slots=torch.where(ids==e)
        if not rows.numel():continue
        z=xin[rows]@w1[e].T;up,gate=z[:,:n],z[:,n:]
        if wrong:up,gate=gate,up
        mid=up*torch.nn.functional.silu(gate)
        if mode=='nvfp4':mid=qdq(mid)
        y=mid@w2[e].T;out.index_add_(0,rows,y*scales[rows,slots,None])
    return out

def metrics(actual,expected,mode):
    a=actual.float();b=expected.float();finite=bool(torch.isfinite(a).all());den=float(b.norm());assert den>1e-8
    rel=float((a-b).norm()/den);cos=float(torch.nn.functional.cosine_similarity(a.flatten(),b.flatten(),dim=0));p=POLICY[mode]
    return {'relative_l2':rel,'cosine':cos,'max_abs':float((a-b).abs().max()),'finite':finite,'passed':finite and rel<=p['relative_l2_max'] and cos>=p['cosine_min']}

def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);assert os.getenv('SLURM_JOB_ID') and torch.cuda.get_device_capability()[0]==12
    (out/'frozen-policy.json').write_text(json.dumps(POLICY,indent=2));torch.backends.cuda.matmul.allow_tf32=False
    log=(out/'raw.jsonl').open('x',buffering=1)
    def emit(x):s=json.dumps(x,allow_nan=False);log.write(s+'\n');print(s,flush=True)
    emit({'kind':'environment','job':os.getenv('SLURM_JOB_ID'),'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,'flashinfer':flashinfer.__version__,'b12x_source':inspect.getfile(flashinfer.b12x_fused_moe),'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'policy':POLICY})
    passed=0;failed=0
    for seed in [59017,91387]:
        torch.manual_seed(seed);E,H,N,K=16,512,512,2;w1,q1,s1=weights(E,2*N,H);w2,q2,s2=weights(E,H,N);alpha=torch.ones(E,device='cuda')
        for m in [1,2,4,8,16,32,64,128]:
            x=torch.randn(m,H,device='cuda',dtype=torch.bfloat16)*.1;vals,ids=torch.randn(m,E,device='cuda').topk(K,dim=-1);ids=ids.int();scales=vals.softmax(-1).float()
            for mode in ['w4a16','nvfp4']:
                try:
                    kw=dict(x=x,w1_weight=q1,w1_weight_sf=s1,w2_weight=q2,w2_weight_sf=s2,w1_alpha=alpha,w2_alpha=alpha,token_selected_experts=ids,token_final_scales=scales,num_experts=E,top_k=K,output=torch.empty_like(x),quant_mode=mode,source_format='modelopt')
                    if mode=='nvfp4':kw['fc2_input_scale']=torch.ones(1,device='cuda')
                    ref=reference(x,w1,w2,ids,scales,mode);wrong=reference(x,w1,w2,ids,scales,mode,True)
                    y=flashinfer.b12x_fused_moe(**kw);torch.cuda.synchronize();scores=metrics(y,ref,mode)
                    negatives={name:metrics(a,ref,mode) for name,a in [('zero_output',torch.zeros_like(ref)),('double_output',ref*2),('swapped_gate_and_up',wrong)]}
                    assert not any(v['passed'] for v in negatives.values()),'Gate does not reject a known-invalid result'
                    if not scores['passed']:raise AssertionError('predeclared numerical gate failed: '+json.dumps(scores))
                    for _ in range(3):flashinfer.b12x_fused_moe(**kw)
                    torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
                    with torch.cuda.graph(g):y=flashinfer.b12x_fused_moe(**kw)
                    x.mul_(.9);x.add_(.013);ids.copy_(ids.roll(1,dims=1));newref=reference(x,w1,w2,ids,scales,mode);g.replay();torch.cuda.synchronize();replay=metrics(y,newref,mode);assert replay['passed'],'mutated-input graph replay failed gate'
                    emit({'kind':'case','seed':seed,'M':m,'mode':mode,'status':'PASS','reference':scores,'negative_controls':negatives,'mutated_graph':replay,'speedup_claim':False});passed+=1;del g
                except Exception as e:
                    emit({'kind':'case','seed':seed,'M':m,'mode':mode,'status':'FAIL','error':repr(e),'trace':traceback.format_exc()});failed+=1
    s={'passed':passed,'failed':failed,'expected':32,'full_model':False,'performance_compared':False};(out/'summary.json').write_text(json.dumps(s,indent=2));emit({'kind':'summary',**s})
    if failed or passed!=32:raise SystemExit(1)
if __name__=='__main__':main()
