"""Real SGLang persistent GEMM: resource repro, FP64 oracle, batch invariance."""
import os,sys,inspect,json,hashlib,statistics,traceback,difflib
from pathlib import Path
import torch
import sglang.srt.batch_invariant_ops.batch_invariant_ops as module

def graph(fn):
    for _ in range(3):fn()
    torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        for _ in range(16):result=fn()
    return g,result

def time_us(g):
    a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
    a.record();g.replay();b.record();b.synchronize();return a.elapsed_time(b)*1000/16

def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
    assert os.getenv('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.manual_seed(441913);torch.backends.cuda.matmul.allow_tf32=False
    source=inspect.getsource(module._matmul_persistent_triton);anchor='    # print(a.device, b.device, c.device)\n';assert source.count(anchor)==1
    guard='''    # Keep the three-stage choice on devices with sufficient shared memory.
    # The FP16 128x256x64 configuration exceeds the 99-KiB limit on SM89/SM120.
    if a.dtype == torch.float16 and a.is_cuda and torch.version.hip is None:
        capacity = torch.cuda.get_device_properties(a.device).shared_memory_per_block_optin
        if capacity < 128 * 1024:
            configs[a.dtype]["num_stages"] = 2
'''
    candidate_source=source.replace(anchor,guard+anchor);stage1_source=source.replace(anchor,'    configs[a.dtype]["num_stages"] = 1\n'+anchor)
    ns=dict(module.__dict__);exec(compile(candidate_source,'<capacity-safe-gemm>','exec'),ns);candidate=ns['_matmul_persistent_triton']
    ns1=dict(module.__dict__);exec(compile(stage1_source,'<stage1-control>','exec'),ns1);control=ns1['_matmul_persistent_triton'];baseline=module._matmul_persistent_triton
    full=Path(module.__file__).read_text();full_candidate=full.replace(source,candidate_source);assert full_candidate!=full
    (out/'baseline_module.py').write_text(full);(out/'candidate_module.py').write_text(full_candidate)
    (out/'capacity-guard.patch').write_text(''.join(difflib.unified_diff(full.splitlines(True),full_candidate.splitlines(True),fromfile='a/python/sglang/srt/batch_invariant_ops/batch_invariant_ops.py',tofile='b/python/sglang/srt/batch_invariant_ops/batch_invariant_ops.py')))
    log=(out/'raw.jsonl').open('x',buffering=1)
    def emit(x):s=json.dumps(x,allow_nan=False);log.write(s+'\n');print(s,flush=True)
    props=torch.cuda.get_device_properties(0)
    emit({'kind':'environment','job':os.environ['SLURM_JOB_ID'],'gpu':torch.cuda.get_device_name(),'capability':torch.cuda.get_device_capability(),'torch':torch.__version__,'sglang_module':module.__file__,'shared_capacity_bytes':props.shared_memory_per_block_optin,'baseline_sha256':hashlib.sha256(full.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(full_candidate.encode()).hexdigest(),'seed':441913,'performance_scope':'operator only, graph replay; stage1 is a valid fallback control, not the crashing default'})
    passed=failed=resource_failures=0
    for dtype in [torch.float16,torch.bfloat16,torch.float32]:
      for n,k in [(1536,1536),(8192,2048),(151936,1536),(8193,257)]:
        a_all=torch.randn(129,k,device='cuda',dtype=dtype)*.05;b=torch.randn(n,k,device='cuda',dtype=dtype).T*.05;bias=torch.randn(n,device='cuda',dtype=dtype)*.01
        cols=torch.linspace(0,n-1,min(n,32),device='cuda').long();ref_b=b[:,cols].cpu().double();ref_bias=bias[cols].cpu().double();row0=None
        for m in [1,2,7,16,31,32,64,128,129]:
          try:
            a=a_all[:m];kwargs=dict(out_dtype=dtype,bias=bias);old_error=None
            try:old=baseline(a,b,**kwargs);torch.cuda.synchronize()
            except Exception as ex:
              if 'out of resource: shared memory' not in str(ex):raise
              old=None;old_error=str(ex);resource_failures+=1
            y=candidate(a,b,**kwargs);torch.cuda.synchronize();assert torch.isfinite(y).all()
            ref=((a.cpu().double()@ref_b)+ref_bias).to(dtype);sample=y[:,cols].cpu();rtol,atol={torch.float16:(.004,.001),torch.bfloat16:(.02,.005),torch.float32:(.001,.0003)}[dtype]
            torch.testing.assert_close(sample,ref,rtol=rtol,atol=atol)
            if row0 is None:row0=y[0].clone()
            else:assert torch.equal(row0,y[0]),'Row changes when unrelated rows are added'
            if old is not None:assert torch.equal(old,y),'Untouched dtype/config changed output'
            row={'kind':'case','dtype':str(dtype),'M':m,'N':n,'K':k,'status':'PASS','baseline_resource_error':old_error,'max_reference_abs_error':float((sample.float()-ref.float()).abs().max()),'batch_invariant_row0':True,'untouched_baseline_bitwise_equal':old is not None}
            if dtype==torch.float16 and m in [1,16,64]:
              c=control(a,b,**kwargs);torch.cuda.synchronize();assert torch.equal(y,c),'Stage1 arithmetic differs'
              funcs={'stage2_candidate':lambda:candidate(a,b,**kwargs),'stage1_control':lambda:control(a,b,**kwargs)};graphs={name:graph(fn)[0] for name,fn in funcs.items()};times={name:[] for name in funcs}
              for name in ['stage2_candidate','stage1_control','stage1_control','stage2_candidate']*3:times[name].append(time_us(graphs[name]))
              row['raw_us']=times;row['speedup_vs_stage1']=statistics.median(times['stage1_control'])/statistics.median(times['stage2_candidate']);del graphs
            if dtype==torch.float16 and m==7:
              g,result=graph(lambda:candidate(a,b,**kwargs));a.add_(.003);g.replay();torch.cuda.synchronize();newref=(a.cpu().double()@ref_b+ref_bias).to(dtype);torch.testing.assert_close(result[:,cols].cpu(),newref,rtol=rtol,atol=atol)
              a.sub_(.003);row0=candidate(a_all[:1],b,**kwargs)[0].clone();row['mutated_cuda_graph_passed']=True;del g,result
            emit(row);passed+=1
          except Exception as ex:emit({'kind':'case','dtype':str(dtype),'M':m,'N':n,'K':k,'status':'FAIL','error':repr(ex),'trace':traceback.format_exc()});failed+=1
    summary={'passed':passed,'expected':108,'failed':failed,'baseline_resource_failures':resource_failures,'e2e':False};(out/'summary.json').write_text(json.dumps(summary,indent=2));emit({'kind':'summary',**summary})
    if failed or passed!=108:raise SystemExit(1)
if __name__=='__main__':main()
