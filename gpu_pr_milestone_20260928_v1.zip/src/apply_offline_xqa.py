import ast, difflib, hashlib, json, pathlib, sys
from importlib.util import find_spec
out=pathlib.Path(sys.argv[1]);root=pathlib.Path(find_spec("vllm").origin).parent
f=root/"utils/flashinfer.py";source=f.read_text();tree=ast.parse(source)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="supports_trtllm_attention")
lines=source.splitlines(keepends=True);body="".join(lines[node.lineno-1:node.end_lineno])
anchor="    # Requires NVIDIA artifactory to be accessible to download cubins\n"
assert body.count(anchor)==1,"Unknown dependency gating; refuse uncontrolled replacement"
insert="""    # SM120 dedicated XQA is compiled from bundled CUDA source locally.
    # This prerequisite patch is shared by both D2H comparison arms.
    if current_platform.is_device_capability_family(120) and not is_prefill:
        return True

"""
body2=body.replace(anchor,insert+anchor);updated="".join(lines[:node.lineno-1])+body2+"".join(lines[node.end_lineno:])
compile(updated,str(f),"exec")
(out/"offline-xqa-support.patch").write_text("".join(difflib.unified_diff(source.splitlines(True),updated.splitlines(True),fromfile="a/vllm/utils/flashinfer.py",tofile="b/vllm/utils/flashinfer.py")))
(out/"offline-xqa-support-before.py").write_text(source)
f.write_text(updated)
(out/"offline-xqa-support-provenance.json").write_text(json.dumps({"path":str(f),"before_sha256":hashlib.sha256(source.encode()).hexdigest(),"after_sha256":hashlib.sha256(updated.encode()).hexdigest(),"scope":"explicit source-level prerequisite for SM120 local-JIT decode; NO false package-availability flags; both sync comparison arms use the same change","upstream_acceptance":False},indent=2))
print("ISOLATED_LOCAL_JIT_SUPPORT_PATCH_APPLIED",str(f))
