import pathlib,sys,hashlib,json,difflib
from importlib.util import find_spec
out=pathlib.Path(sys.argv[1]);arm=sys.argv[2];p=pathlib.Path(find_spec('vllm').origin).parent/'v1/attention/backends/flashinfer.py'
backup=out.parent/'backend-uninstrumented.py'
if not backup.exists():backup.write_bytes(p.read_bytes())
s=backup.read_text();old='needs_seq_lens_cpu = self.use_dcp or use_cascade or not all_uses_trtllm';assert s.count(old)==1
if arm=='candidate':s=s.replace(old,'needs_seq_lens_cpu = (self.use_dcp or use_cascade or (num_prefills > 0 and not prefill_use_trtllm) or (num_decodes > 0 and not decode_with_flashinfer_trtllm_api))')
anchor='        if needs_seq_lens_cpu:\n';assert s.count(anchor)==1
hook="""        import os as _pr_os
        _pr_flag = _pr_os.environ.get('PR_ROUTING_ENABLE_FILE')
        if _pr_flag and _pr_os.path.isfile(_pr_flag):
            _pr_n = globals().get('_PR_ROUTE_COUNT', 0)
            if _pr_n < 128:
                import json as _pr_json
                _pr_row = dict(causal=bool(causal), num_prefills=int(num_prefills),
                    num_decodes=int(num_decodes), num_tokens=int(num_actual_tokens),
                    use_xqa=bool(getattr(self,'use_xqa',getattr(self,'use_dedicated_xqa',False))),
                    uses_decode_api=bool(decode_with_flashinfer_trtllm_api),
                    needs_seq_lens_cpu=bool(needs_seq_lens_cpu),
                    speculative_tokens=getattr(self, '_num_speculative_tokens', None))
                with open(_pr_os.environ['PR_ROUTING_LOG'], 'a') as _pr_f:
                    _pr_f.write(_pr_json.dumps(_pr_row)+'\\n')
                globals()['_PR_ROUTE_COUNT'] = _pr_n + 1
"""
s=s.replace(anchor,hook+anchor);compile(s,str(p),'exec');p.write_text(s)
(out/'backend-tested.py').write_text(s);(out/'source-provenance.json').write_text(json.dumps({'arm':arm,'baseline_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'tested_sha256':hashlib.sha256(s.encode()).hexdigest(),'diagnostic_hook_shared':True,'diagnostics_excluded_from_performance':True},indent=2))
(out/'patch.diff').write_text(''.join(difflib.unified_diff(backup.read_text().splitlines(True),s.splitlines(True),fromfile='a/flashinfer.py',tofile='b/flashinfer.py')))
