import sys,pathlib,hashlib,json,difflib,ast
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);stages=int(sys.argv[3]);assert stages in (1,2)
p=root/'sglang/srt/batch_invariant_ops/batch_invariant_ops.py';s=p.read_text();tree=ast.parse(s);n=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='_matmul_persistent_triton');lines=s.splitlines(True);body=''.join(lines[n.lineno-1:n.end_lineno]);anchor='    # print(a.device, b.device, c.device)\n';assert body.count(anchor)==1
insert=f'    if a.dtype == torch.float16 and a.is_cuda and torch.version.hip is None:\n        if torch.cuda.get_device_properties(a.device).shared_memory_per_block_optin < 128 * 1024:\n            configs[a.dtype]["num_stages"] = {stages}\n'
t=s.replace(body,body.replace(anchor,insert+anchor));compile(t,str(p),'exec');p.write_text(t)
(out/f'stage{stages}-patch.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='a/batch_invariant_ops.py',tofile='b/batch_invariant_ops.py')))
(out/f'stage{stages}-source-provenance.json').write_text(json.dumps({'before_sha256':hashlib.sha256(s.encode()).hexdigest(),'after_sha256':hashlib.sha256(t.encode()).hexdigest(),'stages':stages,'preserves_math_tile_and_reduction_order':True},indent=2))
