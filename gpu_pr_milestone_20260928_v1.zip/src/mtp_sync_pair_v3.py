import os,sys,json,time,subprocess,socket,signal,urllib.request,urllib.error,threading,concurrent.futures,hashlib,statistics,math
from pathlib import Path
from transformers import AutoTokenizer

def http(base,path,payload=None,timeout=30):
 body=json.dumps(payload).encode() if payload is not None else b''
 req=urllib.request.Request(base+path,data=body,headers={'Content-Type':'application/json'},method='POST')
 with urllib.request.urlopen(req,timeout=timeout) as r:return r.read()

def main():
 R=Path(sys.argv[1]);assert not (R/'events.jsonl').exists(), 'Do not overwrite prior serving evidence';R.mkdir(parents=True,exist_ok=True);model=Path(sys.argv[2]);assert (model/'COMPLETE.json').exists();mode=sys.argv[3]
 tok=AutoTokenizer.from_pretrained(str(model),local_files_only=True);f=(R/'events.jsonl').open('x');lock=threading.Lock()
 def emit(d):
  s=json.dumps(d,allow_nan=False)
  with lock:f.write(s+'\n');f.flush();print(s,flush=True)
 def prompt(n,tag):
  ids=tok.encode('Document '+tag+': Memory allocation and scheduling must preserve exact sequence lengths. GPU kernels process continuous token batches. ',add_special_tokens=False)
  return (ids*((n+len(ids)-1)//len(ids)))[:n]
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 base=f'http://127.0.0.1:{port}';traces=R/'traces';traces.mkdir()
 cmd=[sys.executable,'-m','vllm.entrypoints.openai.api_server','--model',str(model),'--served-model-name','campaign-qwen35','--host','127.0.0.1','--port',str(port),'--dtype','bfloat16','--attention-backend','FLASHINFER','--max-model-len','65536','--max-num-batched-tokens','4096','--max-num-seqs','4','--gpu-memory-utilization','0.82','--no-enable-prefix-caching','--limit-mm-per-prompt','{"image":0,"video":0}','--profiler-config',json.dumps({'profiler':'torch','torch_profiler_dir':str(traces),'ignore_frontend':True,'max_iterations':40,'torch_profiler_record_shapes':True})]
 if mode.startswith('mtp'):cmd+=['--speculative-config',json.dumps({'method':'mtp','num_speculative_tokens':2})]
 (R/'server-command.json').write_text(json.dumps(cmd,indent=2));out=(R/'server.log').open('x');server=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 emit({'kind':'server_start','pid':server.pid,'mode':mode,'command':cmd,'model_revision':json.loads((model/'COMPLETE.json').read_text())['revision'],'job':os.getenv('SLURM_JOB_ID')})
 def request(name,n,maxnew,first=None):
  ids=prompt(n,name);body={'model':'campaign-qwen35','prompt':ids,'max_tokens':maxnew,'temperature':0,'seed':33710,'ignore_eos':True,'stream':True,'stream_options':{'include_usage':True},'logprobs':1}
  (R/(name+'-request.json')).write_text(json.dumps(body));start=time.perf_counter();chunks=[];full='';usage=None
  req=urllib.request.Request(base+'/v1/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=240) as response:
   for line in response:
    if not line.startswith(b'data:'):continue
    payload=line[5:].strip()
    if payload==b'[DONE]':break
    event=json.loads(payload);now=time.perf_counter()
    if event.get('error'):
     (R/(name+'-stream-error.json')).write_text(json.dumps(event,ensure_ascii=False,indent=2))
     raise RuntimeError('Server returned a streamed error; see saved stream-error.json')
    if event.get('usage'):usage=event['usage']
    for ch in event.get('choices',[]):
     text=ch.get('text','');lp=ch.get('logprobs') or {};count=len(lp.get('tokens')or[])
     if count or text:
      chunks.append({'since_start_s':now-start,'monotonic_s':now,'token_count':count,'text':text,'logprobs':lp});full+=text
      if first:first.set()
  end=time.perf_counter();assert chunks, 'No output chunks'
  (R/(name+'-stream.json')).write_text(json.dumps({'chunks':chunks,'usage':usage,'text':full},ensure_ascii=False))
  times=[x['monotonic_s']for x in chunks];gaps=[1000*(b-a)for a,b in zip(times,times[1:])];cnt=sum(x['token_count']for x in chunks);total=(usage or {}).get('completion_tokens',cnt)
  assert total==maxnew,(name,total,maxnew)
  allsingle=all(x['token_count']==1 for x in chunks)
  row={'kind':'request','name':name,'mode':mode,'input_tokens':n,'output_tokens':total,'wall_s':end-start,'ttft_s':chunks[0]['since_start_s'],'decode_span_s':times[-1]-times[0],'mean_tpot_ms':1000*(times[-1]-times[0])/max(total-1,1),'single_token_chunks_only':allsingle,'chunk_gap_p95_ms':sorted(gaps)[int(.95*(len(gaps)-1))]if gaps else 0,'max_chunk_gap_ms':max(gaps,default=0),'token_itl_p95_ms':sorted(gaps)[int(.95*(len(gaps)-1))]if gaps and allsingle else None,'output_sha256':hashlib.sha256(full.encode()).hexdigest()};emit(row);return row
 try:
  deadline=time.monotonic()+700
  while True:
   if server.poll() is not None:raise RuntimeError('server exited before health; see server.log')
   try:
    with urllib.request.urlopen(base+'/health',timeout=1) as response:
     if response.status==200:break
   except (urllib.error.URLError,TimeoutError):pass
   if time.monotonic()>deadline:raise TimeoutError('server startup deadline exceeded')
   time.sleep(2)
  emit({'kind':'server_ready','mode':mode});request('warmup',64,16)
  request('solo-short',256,256)
  request('solo-long',8192,128)
  with concurrent.futures.ThreadPoolExecutor(2) as pool:
   event=threading.Event();short=pool.submit(request,'mixed-short',256,512,event)
   assert event.wait(90),'short request failed to start'
   long=pool.submit(request,'mixed-long',12288,128)
   short.result();long.result()
  with concurrent.futures.ThreadPoolExecutor(2) as pool:
   futures=[pool.submit(request,'long-pair-a',32768,128),pool.submit(request,'long-pair-b',49152,128)]
   for fut in futures:fut.result()
  flag=Path(os.environ['PR_ROUTING_ENABLE_FILE']);flag.write_text('enabled')
  try:
   request('diagnostic-mtp',256,32)
   with concurrent.futures.ThreadPoolExecutor(2) as pool:
    event=threading.Event();short=pool.submit(request,'diagnostic-mixed-short',256,128,event)
    assert event.wait(90)
    long=pool.submit(request,'diagnostic-mixed-long',8192,32)
    short.result();long.result()
  finally:flag.unlink(missing_ok=True)
  emit({'kind':'completed','mode':mode,'no_crash_on_named_workloads':True,'not_exact_original_environment':True})
 finally:
  if server.poll() is None:
   os.killpg(server.pid,signal.SIGTERM)
   try:server.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
  (R/'server-exit.txt').write_text(str(server.returncode));out.close();f.close()
if __name__=='__main__':main()
