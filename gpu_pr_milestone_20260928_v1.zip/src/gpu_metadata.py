"""Real CUDA attention and metadata tests; not a full-model serving benchmark."""
import argparse, contextlib, hashlib, inspect, json, math, os, statistics, sys, textwrap, time, traceback
from pathlib import Path
import torch
from torch.utils._python_dispatch import TorchDispatchMode
from vllm.config import CacheConfig, CompilationConfig, DeviceConfig, LoadConfig, ModelConfig, ParallelConfig, SchedulerConfig, SpeculativeConfig, VllmConfig, set_current_vllm_config
from vllm.model_executor.layers.attention.attention import Attention
from vllm.v1.attention.backend import CommonAttentionMetadata
from vllm.v1.attention.backends import flashinfer as fi
from vllm.v1.kv_cache_interface import FullAttentionSpec
import vllm, triton, flashinfer

OLD = 'needs_seq_lens_cpu = self.use_dcp or use_cascade or not all_uses_trtllm'
NEW = '''needs_seq_lens_cpu = (
            self.use_dcp
            or use_cascade
            or (num_prefills > 0 and not prefill_use_trtllm)
            or (num_decodes > 0 and not decode_with_flashinfer_trtllm_api)
        )'''

class CopyAudit(TorchDispatchMode):
    def __init__(self, lengths):
        super().__init__(); self.ptr=lengths.data_ptr(); self.events=[]
    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs=kwargs or {}
        if func == torch.ops.aten._to_copy.default and args and isinstance(args[0],torch.Tensor):
            dev=kwargs.get('device')
            if args[0].is_cuda and dev is not None and torch.device(dev).type=='cpu':
                self.events.append({'shape':list(args[0].shape),'is_seq_lens':args[0].data_ptr()==self.ptr})
        return func(*args,**kwargs)

def make_config(path, d, use_native):
    path.mkdir(exist_ok=True)
    (path/'config.json').write_text(json.dumps({'model_type':'llama','architectures':['LlamaForCausalLM'],'hidden_size':8*d,'intermediate_size':2048,'num_hidden_layers':1,'num_attention_heads':8,'num_key_value_heads':2,'head_dim':d,'vocab_size':128,'max_position_embeddings':65536,'torch_dtype':'bfloat16','rope_theta':10000.,'rms_norm_eps':1e-5}))
    mc=ModelConfig(model=str(path),tokenizer=str(path),dtype='bfloat16',seed=99173,max_model_len=65536)
    cc=CacheConfig(block_size=16,cache_dtype='auto');cc.num_gpu_blocks=65536;cc.num_cpu_blocks=0;cc.kv_cache_layout='LBNHC'
    vc=VllmConfig(model_config=mc,cache_config=cc,parallel_config=ParallelConfig(),scheduler_config=SchedulerConfig(max_num_seqs=8,max_num_batched_tokens=1024,max_model_len=65536,enable_chunked_prefill=True,is_encoder_decoder=False),device_config=DeviceConfig(),load_config=LoadConfig(),compilation_config=CompilationConfig())
    vc.attention_config.use_trtllm_attention=False if use_native else None
    vc.speculative_config=SpeculativeConfig(method='ngram',num_speculative_tokens=3)
    return vc

def make_case(seq, qlens, causal, d, layout, upper_extra):
    dev='cuda';hq,hk,page=8,2,16;nr=len(seq);nb=[(x+page-1)//page for x in seq];nblocks=1+sum(nb)
    logical=(1,nblocks,hk,page,2*d);physical=tuple(logical[i] for i in layout.stride_order);inv=[layout.stride_order.index(i) for i in range(5)]
    kv=torch.zeros(physical,dtype=torch.bfloat16,device=dev).permute(*inv)[0]
    table=torch.zeros(nr,max(nb),dtype=torch.int32,device=dev);slots=[];keys=[];values=[];qs=[];refs=[];offset=1
    for i,(s,q,n) in enumerate(zip(seq,qlens,nb)):
        k=torch.randn(s,hk,d,device=dev,dtype=torch.bfloat16)*.2;v=torch.randn_like(k)*.2;x=torch.randn(q,hq,d,device=dev,dtype=torch.bfloat16)*.2
        t=torch.arange(s,device=dev);kv[offset+t//page,:,t%page,:d]=k;kv[offset+t//page,:,t%page,d:]=v
        table[i,:n]=torch.arange(offset,offset+n,dtype=torch.int32,device=dev)
        current=torch.arange(s-q,s,device=dev);slots.append((offset+current//page)*page+current%page)
        keys.append(k[s-q:]);values.append(v[s-q:]);qs.append(x)
        if q:
            kk=k.float().repeat_interleave(hq//hk,dim=1);vv=v.float().repeat_interleave(hq//hk,dim=1)
            scores=torch.einsum('qhd,khd->hqk',x.float(),kk)/math.sqrt(d)
            if causal:
                visible=torch.arange(s,device=dev)[None,:] <= (s-q+torch.arange(q,device=dev))[:,None]
                scores=scores.masked_fill(~visible[None],float('-inf'))
            refs.append(torch.einsum('hqk,khd->qhd',scores.softmax(-1),vv))
        offset+=n
    qcpu=torch.tensor([0]+list(torch.tensor(qlens).cumsum(0).tolist()),dtype=torch.int32)
    exact=torch.tensor(seq,dtype=torch.int32,device=dev);upper=torch.tensor(seq,dtype=torch.int32)+torch.tensor(upper_extra,dtype=torch.int32)
    meta=CommonAttentionMetadata(query_start_loc=qcpu.to(dev),query_start_loc_cpu=qcpu,seq_lens=exact,seq_lens_cpu_upper_bound=upper,num_reqs=nr,num_actual_tokens=sum(qlens),max_query_len=max(qlens),max_seq_len=int(upper.max()),block_table_tensor=table,slot_mapping=torch.cat(slots).long(),causal=causal)
    return meta,kv,torch.cat(qs),torch.cat(keys),torch.cat(values),torch.cat(refs)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);args=ap.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    assert os.getenv('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.manual_seed(99173);torch.backends.cuda.matmul.allow_tf32=False;torch.set_default_dtype(torch.bfloat16)
    log=(out/'raw.jsonl').open('x',buffering=1)
    def emit(x):s=json.dumps(x,allow_nan=False);log.write(s+'\n');print(s,flush=True)
    source=inspect.getsource(fi.FlashInferMetadataBuilder.build)
    assert source.count(OLD)==1,'Exact candidate anchor missing: do not silently patch a different version'
    ns={};exec(compile(textwrap.dedent(source).replace(OLD,NEW),'<candidate_native_length_gating>','exec'),fi.__dict__,ns)
    before=fi.FlashInferMetadataBuilder.build;after=ns['build']
    (out/'baseline_build.py').write_text(textwrap.dedent(source));(out/'candidate_build.py').write_text(textwrap.dedent(source).replace(OLD,NEW))
    module_path=Path(fi.__file__);(out/'baseline_flashinfer.py').write_bytes(module_path.read_bytes())
    env={'kind':'environment','gpu':torch.cuda.get_device_name(),'capability':torch.cuda.get_device_capability(),'torch':torch.__version__,'vllm':vllm.__version__,'triton':triton.__version__,'flashinfer':flashinfer.__version__,'job':os.environ['SLURM_JOB_ID'],'source_path':str(module_path),'source_sha256':hashlib.sha256(module_path.read_bytes()).hexdigest(),'scope':'real CUDA layer and native/XQA metadata; fixed model-config fixture, not end-to-end model','length_policy':'GPU exact values unchanged; never substitute speculative CPU upper bound'};emit(env)
    cases=[('causal-decode',[17,35],[1,1],True,[3,2]),('noncausal-decode',[17,35],[1,1],False,[3,2]),('causal-spec',[19,65],[4,4],True,[2,1]),('noncausal-spec',[19,65],[4,4],False,[2,1]),('causal-mixed',[33,257],[4,64],True,[3,0]),('noncausal-mixed',[33,257],[4,64],False,[3,0]),('causal-prefill',[65,129],[17,33],True,[0,0]),('noncausal-prefill',[65,129],[17,33],False,[0,0]),('noncausal-long',[4097,8191],[4,4],False,[3,2]),('causal-mixed-long',[8193,16385],[4,128],True,[3,0])]
    failures=[];results=[]
    for d in [128,256]:
      for use_native in [True,False]:
        vc=make_config(out/f'config-{d}-{use_native}',d,use_native)
        with set_current_vllm_config(vc):
          layer=Attention(8,d,1/math.sqrt(d),num_kv_heads=2,cache_config=vc.cache_config,prefix='layer.0',attn_backend=fi.FlashInferBackend)
          spec=FullAttentionSpec(block_size=16,num_kv_heads=2,head_size=d,dtype=torch.bfloat16)
          builder=fi.FlashInferMetadataBuilder(spec,['layer.0'],vc,torch.device('cuda:0'))
          emit({'kind':'builder','head_dim':d,'forced_native':use_native,'use_xqa':builder.use_xqa,'decode_threshold':builder.reorder_batch_threshold})
          for name,seq,ql,causal,extra in cases:
            try:
              common,kv,q,k,v,ref=make_case(seq,ql,causal,d,builder.kv_cache_layout,extra)
              immutable=common.seq_lens.clone();upper=common.seq_lens_cpu_upper_bound.clone();outputs={};audits={};metadata={}
              for label,method in [('baseline',before),('candidate',after)]:
                with CopyAudit(common.seq_lens) as audit:meta=method(builder,0,common)
                torch.cuda.synchronize();audits[label]=audit.events;metadata[label]=meta
                y=torch.empty_like(q);layer.impl.forward(layer,q,k,v,kv,meta,output=y);torch.cuda.synchronize()
                torch.testing.assert_close(y.float(),ref,rtol=.015,atol=.003);outputs[label]=y.clone()
              assert torch.equal(outputs['baseline'],outputs['candidate']),'Candidate changes CUDA output'
              assert torch.equal(common.seq_lens,immutable) and torch.equal(common.seq_lens_cpu_upper_bound,upper)
              meta=metadata['candidate'];native_consumers=(meta.num_prefills>0) or (not builder.use_xqa)
              counts={l:sum(e['is_seq_lens'] for e in a) for l,a in audits.items()}
              if builder.use_xqa and not causal and meta.num_prefills==0:assert counts=={'baseline':1,'candidate':0},counts
              elif counts['baseline']!=counts['candidate']:raise AssertionError(('unexpected copy-count change',counts))
              row={'kind':'case','name':name,'head_dim':d,'forced_native':use_native,'use_xqa':builder.use_xqa,'seq_lens':seq,'cpu_upper_bound':upper.tolist(),'query_lens':ql,'num_prefills':meta.num_prefills,'num_decodes':meta.num_decodes,'seq_lens_d2h_copies':counts,'all_d2h':audits,'max_abs_error':float((outputs['candidate'].float()-ref).abs().max()),'bitwise_equal':True,'lengths_unchanged':True,'status':'PASS'}
              if name=='noncausal-spec' and builder.use_xqa:
                scratch=torch.randn(1024,1024,device='cuda',dtype=torch.bfloat16)*.01;dst=torch.empty_like(scratch);samples={}
                for backlog in [0,16]:
                  samples[str(backlog)]={'baseline':[],'candidate':[]}
                  for label in ['baseline','candidate','candidate','baseline']*4:
                    torch.cuda.synchronize()
                    for _ in range(backlog):torch.mm(scratch,scratch,out=dst)
                    start=time.perf_counter_ns();(before if label=='baseline' else after)(builder,0,common);elapsed=(time.perf_counter_ns()-start)/1000
                    torch.cuda.synchronize();samples[str(backlog)][label].append(elapsed)
                row['host_build_us']=samples;row['timing_scope']='builder host latency; backlog=real 1024x1024 BF16 GEMMs; not serving throughput'
                with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
                  with torch.profiler.record_function('BASELINE_BUILD'):before(builder,0,common)
                  with torch.profiler.record_function('CANDIDATE_BUILD'):after(builder,0,common)
                  torch.cuda.synchronize()
                prof.export_chrome_trace(str(out/f'trace-d{d}.json'))
              results.append(row);emit(row)
            except Exception as exc:
              row={'kind':'case','name':name,'head_dim':d,'forced_native':use_native,'status':'FAIL','error':repr(exc),'trace':traceback.format_exc()};failures.append(row);emit(row)
    summary={'passed':len(results),'expected':40,'failed':len(failures),'candidate_scope':'skip unused seq_lens D2H for all-XQA noncausal batches; mixed native paths remain exact','e2e':False};(out/'summary.json').write_text(json.dumps(summary,indent=2));emit({'kind':'summary',**summary})
    if failures or len(results)!=40:raise SystemExit(1)
if __name__=='__main__':main()
