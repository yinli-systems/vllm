import os,sys,json,time,hashlib,math,platform
from pathlib import Path
import torch,sglang as sgl
def emit(row):s=json.dumps(row,allow_nan=False);log.write(s+'\n');log.flush();print(s,flush=True)
def sanitize(x):
 if isinstance(x,float) and not math.isfinite(x):return str(x)
 if isinstance(x,list):return [sanitize(v)for v in x]
 if isinstance(x,tuple):return [sanitize(v)for v in x]
 if isinstance(x,dict):return {k:sanitize(v)for k,v in x.items()}
 return x
if __name__=='__main__':
 R=Path(sys.argv[1]);R.mkdir(parents=True,exist_ok=False)
 model=Path(sys.argv[2]);assert (model/'COMPLETE.json').exists()
 log=(R/'events.jsonl').open('x')
 assert os.getenv('SLURM_JOB_ID')
 deterministic=os.environ.get('PR_DETERMINISTIC')=='1'
 cfg=dict(model_path=str(model),dtype='float16',quantization='gptq_marlin',tp_size=1,context_length=4096,mem_fraction_static=.65,disable_radix_cache=True,max_running_requests=1,random_seed=33710,attention_backend='triton',disable_cuda_graph=False,cuda_graph_max_bs_decode=4,disable_prefill_cuda_graph=True,enable_deterministic_inference=deterministic,log_level='info')
 emit({'kind':'environment','job':os.environ['SLURM_JOB_ID'],'gpu':torch.cuda.get_device_name(),'host':platform.node(),'torch':torch.__version__,'sglang':sgl.__version__,'sglang_path':sgl.__file__,'config':cfg,'model_provenance':json.loads((model/'COMPLETE.json').read_text()),'atomic_env':os.getenv('SGLANG_MARLIN_USE_ATOMIC_ADD')})
 engine=sgl.Engine(**cfg)
 try:
  prompts=[f'Give a precise short answer. {q}\nAnswer:'for q in ['What is 13 multiplied by 7?','Explain why the sky appears blue.','Write a Python function to add two integers.','Name three properties of a triangle.']]*4
  params={'temperature':0.,'max_new_tokens':32,'ignore_eos':True}
  engine.generate(prompts[:1],params,return_logprob=True,top_logprobs_num=5)
  hashes=[];timings=[];token_rows=[]
  for repeat in range(4):
   t=time.perf_counter();out=engine.generate(prompts,params,return_logprob=True,top_logprobs_num=5);wall=time.perf_counter()-t
   (R/f'outputs-{repeat}.json').write_text(json.dumps(sanitize(out),indent=2,allow_nan=False))
   tokens=[];values=[];count=0
   for obj in out:
    meta=obj['meta_info'];entries=meta['output_token_logprobs'];count+=meta['completion_tokens']
    tokens.append([v[1] for v in entries]);values.append({'sampled':entries,'top5':meta.get('output_top_logprobs')})
    assert all(math.isfinite(v[0]) for v in entries if v[0] is not None)
   blob=json.dumps(sanitize(values),sort_keys=True,separators=(',',':')).encode();h=hashlib.sha256(blob).hexdigest()
   th=hashlib.sha256(json.dumps(tokens).encode()).hexdigest();hashes.append(h);token_rows.append(th);timings.append(wall)
   emit({'kind':'repeat','repeat':repeat,'wall_seconds':wall,'completion_tokens':count,'output_tokens_per_second':count/wall,'logprob_sha256':h,'token_sha256':th})
  summary={'unique_logprob_hashes':len(set(hashes)),'unique_token_hashes':len(set(token_rows)),'logprob_hashes':hashes,'token_hashes':token_rows,'raw_wall_seconds':timings,'scope':'real pretrained 1.5B GPTQ model; offline engine wall-time, not streaming ITL'}
  (R/'summary.json').write_text(json.dumps(summary,indent=2));emit({'kind':'summary',**summary})
 finally:engine.shutdown()
